# fenixapi
An API to interface with fenix.tecnico.ulisboa.pt